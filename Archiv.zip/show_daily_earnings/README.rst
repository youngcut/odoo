.. |company| replace:: YOUNGCUT


.. |icon| image:: https://github.com/youngcut/odoo/blob/12.0/show_daily_earnings/static/description/icon.png?raw=1

.. image:: https://github.com/youngcut/odoo/blob/12.0/show_daily_earnings/static/description/screenshot_daily.png?raw=1
   :alt: Show Daily Earnings


Show Daily Earnings
===================

This Plugin will show you the total of you daily revenues.
The Amough is shown on the right corner of Point of Sales. (Beneath the print Icon)

Use this Plugin instead of printing a summary ticket each time.