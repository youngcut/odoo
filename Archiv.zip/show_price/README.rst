.. |company| replace:: YOUNGCUT

.. |icon| image:: https://github.com/youngcut/odoo/blob/12.0/show_price/static/description/icon.png?raw=1

.. image:: https://github.com/youngcut/odoo/blob/12.0/show_price/static/description/screenshot_sale.jpg?raw=1
   :alt: Show Price

Show Price
==========

This Plugin will show you the purchase price by hovering/tabing on the price-tag.
