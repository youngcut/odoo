.. |company| replace:: YOUNGCUT

.. |icon| image:: https://github.com/youngcut/odoo/blob/12.0/show_price/static/description/icon.png?raw=1

.. image:: https://github.com/youngcut/odoo/blob/12.0/show_price/static/description/screenshot.jpg?raw=1
   :alt: Show Price

Pos Tags
==========

This Plugin will let you show and edit the Tags of you customer.
