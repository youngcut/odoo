.. |company| replace:: YOUNGCUT

.. |icon| image:: https://github.com/youngcut/odoo/blob/12.0/show_price/static/description/icon.png?raw=1

Sort by bestsellers
===================

Point of Sale: Order all your product by their selling-count.
The often you selling a Product, the higher is the position of that product.

You'il see your most important products in the first page of POS without scrolling.

This Plugin doesn't change the order of your product outside point of sale.

The Sale-Module required!