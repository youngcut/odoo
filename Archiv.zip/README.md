# Odoo plugins

In this Repository, you'il find a few useful Plugins for the Point of Sale-Module in Odoo 12:

- Show daily earnings: Shows daily earning at the right corner of point of sales.
- Show price: Shows purchase price on product. (By hovering/tipping at the pricetag)
- Sort by Bestsellers: This addon will sort products by bestsellers in point of sales!
- POS Tags: This Plugin will let you show and edit the Tags of you customer.
- POS Sales History: See a quick overview of all products for each customer and where bought it (POS/Online).

